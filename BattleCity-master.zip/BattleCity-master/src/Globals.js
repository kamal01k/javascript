Globals = {};

Globals.UNIT_SIZE = 32;
Globals.TILE_SIZE = Globals.UNIT_SIZE / 2;

Globals.CANVAS_WIDTH = Globals.UNIT_SIZE * 16;
Globals.CANVAS_HEIGHT = Globals.UNIT_SIZE * 14;
