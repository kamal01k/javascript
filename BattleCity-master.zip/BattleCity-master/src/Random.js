function Random() {}

Random.prototype.getNumber = function () {
  return Math.random();
};
