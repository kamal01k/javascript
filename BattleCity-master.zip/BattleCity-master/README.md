JavaScript/HTML5 remake of the NES "Battle City" game
=====================================================

[Play](http://newagebegins.github.com/BattleCity/BattleCity.html)  
[Run tests](http://newagebegins.github.com/BattleCity/SpecRunner.html)

The code was written with TDD (Test-Driven Development) methodology.

![Screenshot of the Battle City game](screenshot.jpg)
